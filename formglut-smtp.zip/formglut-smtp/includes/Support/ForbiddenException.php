<?php

namespace FormglutMail\Includes\Support;

use Exception;

class ForbiddenException extends Exception
{
    // ...
}
