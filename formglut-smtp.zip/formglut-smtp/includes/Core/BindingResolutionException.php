<?php

namespace FormglutMail\Includes\Core;

class BindingResolutionException extends \Exception {}
