<?php namespace FormglutMail\App\Services\DB\Viocon;


class VioconException extends \Exception
{

}
