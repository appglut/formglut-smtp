<?php namespace FormglutMail\App\Services\DB;

class Exception extends \Exception
{

}
