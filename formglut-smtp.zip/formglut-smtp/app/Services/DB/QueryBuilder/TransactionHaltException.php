<?php

namespace FormglutMail\App\Services\DB\QueryBuilder;

class TransactionHaltException extends \Exception
{
}
